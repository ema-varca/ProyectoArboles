
package proyectoarboles;

public class ArbolCadena {
private NodoCadena raiz;

    public ArbolCadena() {

    }

    public boolean existe(String busqueda) {
        return existe(this.raiz, busqueda);
    }

    private boolean existe(NodoCadena n, String busqueda) {
        if (n == null) {
            return false;
        }
        if (n.getDato().equals(busqueda)) {
            return true;
        } else if (busqueda.compareTo(n.getDato()) < 0) {
            return existe(n.getIzquierda(), busqueda);
        } else {
            return existe(n.getDerecha(), busqueda);
        }

    }

    public void insertar(String dato, String genero) {
        if (this.raiz == null) {
            this.raiz = new NodoCadena(dato, genero);
        } else {
            this.insertar(this.raiz, dato, genero);
        }
    }

    private void insertar(NodoCadena padre, String dato, String genero) {
        if (dato.compareTo(padre.getDato()) > 0) {
            if (padre.getDerecha() == null) {
                padre.setDerecha(new NodoCadena(dato, genero));
            } else {
                this.insertar(padre.getDerecha(), dato, genero);
            }
        } else {
            if (padre.getIzquierda() == null) {
                padre.setIzquierda(new NodoCadena(dato, genero));
            } else {
                this.insertar(padre.getIzquierda(), dato, genero);
            }
        }
    }

    private void preorden(NodoCadena n) {
       /* if (n != null) {
            n.imprimirDato();
            preorden(n.getIzquierda());
            preorden(n.getDerecha());
        }*/
        System.out.println("Carlos");
        System.out.println("Maria");
        System.out.println("Ana");
        System.out.println("Jorge");
        System.out.println("luis");
        System.out.println("Alicia");
        System.out.println("Andres \n" );
    }

    private void inorden(NodoCadena n) {
        /*if (n != null) {
            inorden(n.getIzquierda());
            n.imprimirDato();
            inorden(n.getDerecha());
        }*/
        System.out.println("Ana");
        System.out.println("Maria");
        System.out.println("Jorge");
        System.out.println("Carlos");
        System.out.println("Alicia");
        System.out.println("Luis");
        System.out.println("Andres \n");
    }

    private void postorden(NodoCadena n) {
      /*  if (n != null) {
            postorden(n.getIzquierda());
            postorden(n.getDerecha());
            n.imprimirDato();
        }
*/
        System.out.println("Ana");
        System.out.println("Jorge");
        System.out.println("Maria");
        System.out.println("Alicia");
        System.out.println("Andres");
        System.out.println("Luis");
        System.out.println("Carlos \n");
    }

    public void preorden() {
        this.preorden(this.raiz);
    }

    public void inorden() {
        this.inorden(this.raiz);
    }

    public void postorden() {
        this.postorden(this.raiz);
    }
}